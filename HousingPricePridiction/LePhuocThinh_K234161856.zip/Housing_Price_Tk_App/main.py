from UIPrediction import UIPrediction

if __name__ == '__main__':
    ui = UIPrediction()
    ui.create_ui()
    ui.show_ui()