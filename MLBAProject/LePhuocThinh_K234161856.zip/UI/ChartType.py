from enum import Enum

class ChartType(Enum):
    PieChart=1
    LinePlotChart=2
    BarChart=3
    BarPlot=4
    MultiBarChart=5
    ScatterPlot=6
